package com.poo.entidadbancomartin.entidades.packcuentas;


import com.poo.entidadbancomartin.entidades.packclientes.ClientesEmpresa;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString(callSuper = true)

public class CuentaConvertibilidad extends CuentaCorriente {
    private double saldoDolares;

    public CuentaConvertibilidad( double montoautorizado, ClientesEmpresa cliente, int numerocuenta) {
        super(montoautorizado, cliente, numerocuenta);
        this.saldoDolares = saldoDolares;
    }
    

 





    public double getSaldoDolares() {
        return saldoDolares;
    }
    {
    }
    
    // 1. Depositar dólares

    public void depositarDolares(double monto) {
        if (monto > 0) {
            this.saldoDolares += monto;
            System.out.println("Depósito exitoso. Nuevo saldo dólares: u$s " + this.saldoDolares);
        } else {
            System.out.println("El monto a depositar debe ser mayor a cero.");
        }
    }

    // 2. Extraer dólares
    
    public void extraerDolares(double monto) {
        if (monto > 0 && this.saldoDolares >= monto) {
            this.saldoDolares -= monto;
            System.out.println("Extracción exitosa. Nuevo saldo dólares: u$s " + this.saldoDolares);
        } else {
            System.out.println("Error: Fondos insuficientes en dólares. No se acepta giro en descubierto.");
        }
    }

    // 3. Convertir pesos a dólares
    public void convertirPesosADolares(double montoPesos, double tasaConversion) {
        if (montoPesos > 0) {
            this.saldo -= montoPesos; // Permite girar en descubierto al comprar dólares
            double dolaresComprados = montoPesos / tasaConversion;
            this.saldoDolares += dolaresComprados;
            System.out.println("Conversión exitosa. Compraste u$s " + dolaresComprados);
        }
    }

    // 4. Convertir dólares a pesos     
    
    public void convertirDolaresAPesos(double montoDolares, double tasaConversion) {
        if (montoDolares > 0 && this.saldoDolares >= montoDolares) {
            this.saldoDolares -= montoDolares;
            double pesosObtenidos = montoDolares * tasaConversion;
            this.saldo += pesosObtenidos;
            System.out.println("Conversión exitosa. Vendiste u$s " + montoDolares + " y obtuviste $" + pesosObtenidos);
        } else {
            System.out.println("Error: No tenés suficientes dólares en cuenta para convertir.");
        }
    }


 

}
