package com.poo.entidadbancomartin.entidades.packclientes; // paquete que contiene las clases que representan a los clientes de la entidad bancaria, // y que pueden tener una o varias cuentas asociadas a su nombre, y que pueden realizar operaciones



import lombok.Getter;

import lombok.ToString;

@Getter
@ToString 


public abstract class Cliente {

    public Cliente(int nroCliente) {
        this.nroCliente = nroCliente;
    }
    private final int nroCliente;


   

}

