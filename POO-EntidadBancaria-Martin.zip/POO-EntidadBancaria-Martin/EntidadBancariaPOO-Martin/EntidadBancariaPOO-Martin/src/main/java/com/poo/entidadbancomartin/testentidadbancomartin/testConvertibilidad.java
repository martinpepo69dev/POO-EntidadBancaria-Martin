package com.poo.entidadbancomartin.testentidadbancomartin;

import com.poo.entidadbancomartin.entidades.packclientes.Cliente;
import com.poo.entidadbancomartin.entidades.packclientes.ClientesEmpresa;
import com.poo.entidadbancomartin.entidades.packcuentas.CuentaConvertibilidad;
import com.poo.entidadbancomartin.entidades.packcuentas.CuentaCorriente;

public class testConvertibilidad {
    public static void main(String[] args) {

        // fucionan los 4 metodos de cuentaConvertibilidad:
        // extraer y depositar dolares , convertir pesos a dolares y convertir dolares a
        // pesos
        // tambien se puede visualizar el saldo en dolares y el saldo en pesos de la
        // cuenta convertibilidad
        // se puede crear una cuenta convertibilidad con un cliente nulo y aun asi se
        // puede depositar dolares y convertir pesos a dolares y dolares a pesos

        // se puede crear una cuenta convertibilidad a traves de la clase cuenta
        // corriente ya que hereda de ella
        Cliente cliente8 = new ClientesEmpresa(999, "Poo", "953533");

    }

}
